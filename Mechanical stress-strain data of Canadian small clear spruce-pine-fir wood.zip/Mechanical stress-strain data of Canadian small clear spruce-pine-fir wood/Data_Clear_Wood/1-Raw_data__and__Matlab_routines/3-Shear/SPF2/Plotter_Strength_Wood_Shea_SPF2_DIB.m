% #***********************************************************#
% #******  This is a little program to plot wood shear  ******#
% #**********  strength probability distributions ************#
% #*********************  SESS Lab./UBC  *********************#
% #*********** (c)  Bleriot Feujofack, 2022  *****************#
% #** bleriotvincent (dot) feujofackkemda (at) ubc (dot) ca **#
% #***********************************************************#

clear all
clfall
 
%% Read the Meta data file
Meta=readtable('Meta_Data_Clear_Wood.xlsx','Sheet','Shea_SPF2');
MetaData=table2array(Meta);



%% Read the text files
   jDIB=1;
    for j=1:65
        T=[];
    specimenCodeTxtOut=strcat('VSA',num2str(j),'_raw.txt');
    color='k';

    if j<=9
    specimenCodeTxtOut=strcat('VSA0',num2str(j),'_raw.txt');
    end

T = readtable(specimenCodeTxtOut);
T1=table2array(T);


%Zero the load reading
T1(:,2)=T1(:,2)-T1(1,2);
 

%Zero the deformation reading
T1(:,3)=-(T1(:,3)-T1(1,3));



%% Delete the post-peak part
LoadCutOff=1;

for k=1:size(T1,1)
    if T1(k,2)==max(T1(:,2))
       
       LoadCutOffID=k; 
        break
    end 
end 

%% Calculate the maximum strength and update the MetaData
MetaData(j,4)=T1(LoadCutOffID,2)/(MetaData(j,2)*MetaData(j,3));

outData(j,:)=[j MetaData(j,4)];

    end



writecell({'Test ID (-)', 'Strength (MPa)'},'preamble.txt','Delimiter','tab')

writematrix(num2str(outData,'%.10f '),'test.txt','Delimiter','tab')
system('copy /b preamble.txt+test.txt VSAAll.txt');



%% Write the data in the xls file
filename='Meta_Data_Clear_Wood.xlsx';
writematrix(MetaData(:,4),filename,'sheet','Shea_SPF2','Range','D2');


    
   %% Probability

X=MetaData(:,4);
[pdStrength]=createFit(X); 
    

function [pdStrength] = createFit(X)
%CREATEFIT    Create plot of datasets and fits
%   [PD1,PD2,PD3] = CREATEFIT(X,Y)
%   Creates a plot, similar to the plot in the main distribution fitter
%   window, using the data that you provide as input.  You can
%   apply this function to the same data you used with dfittool
%   or with different data.  You may want to edit the function to
%   customize the code and this help message.
%
%   Number of datasets:  2
%   Number of fits:  3

% Data from dataset "X data":
%    Y = X

% Data from dataset "Y data":
%    Y = Y
%         1      2        3    4           5             6
distb={'burr','weibull','ev','gev','inversegaussian','nakagami'};
distb1=distb{4};


figure (3)
% Force all inputs to be column vectors
X = X;


% Prepare figure
clf;
hold on;
LegHandles = []; LegText = {};


% --- Plot data originally in dataset "X data"
[CdfF,CdfX] = ecdf(X,'Function','cdf');  % compute empirical cdf
BinInfo.rule = 3;
BinInfo.nbins = 7;
% BinInfo.rule = 4;
[~,BinEdge] = internal.stats.histbins(X,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight,'hist');
set(hLine,'FaceColor','k','FaceAlpha',.05,'EdgeColor','k',...
    'LineStyle','-', 'LineWidth',1);
xlabel('Strength, MPa ','fontweight','bold','Fontsize',13,'FontName','cmr12');
ylabel('Density')
LegHandles(end+1) = hLine;
LegText{end+1} = 'Exp. Strength';

set(gca,'FontSize',13);

grid on;

% Create grid where function will be computed
XLim = get(gca,'XLim');
XLim = XLim + [0 100] * 0.01 * diff(XLim);
XGrid = linspace(.5*XLim(1),1.05*XLim(2),100);


% --- Create fit "fit 1" - Strength

% Fit this distribution to get parameter values
pd1 = fitdist(X, distb1);
pdStrength=pd1;
YPlot = pdf(pd1,XGrid);
hLine = plot(XGrid,YPlot,'Color','k',...
    'LineStyle','-', 'LineWidth',2,...
    'Marker','none', 'MarkerSize',6);
LegHandles(end+1) = hLine;
LegText{end+1} = 'fit - Strength';


text(7, .50, sprintf('\\mu = %.2f', mean(pdStrength)),'FontSize', 12, 'Color', 'k', 'FontWeight', 'bold');
text(7, .45, sprintf('\\sigma = %.2f', std(pdStrength)),'FontSize', 12, 'Color', 'k', 'FontWeight', 'bold');


% Adjust figure
box on;
hold off;

% Create legend from accumulated handles and labels
hLegend = legend(LegHandles,LegText,'Orientation', 'vertical', 'FontSize', 9, 'Location', 'northeast');
set(hLegend,'Interpreter','none');



set(gca,'FontSize',13,'FontName','Trebuchet');
print('PDFVSA','-dmeta')





figure (4)

% Prepare figure
clf;
hold on;
LegHandles = []; LegText = {};


% --- Plot data originally in dataset "X data"

[CdfY,CdfX] = ecdf(X,'Function','cdf');  % compute empirical function
hLine = stairs(CdfX,CdfY,'Color','k','LineStyle','-', 'LineWidth',.5);
xlabel('Strength, MPa');
ylabel('Cumulative probability')
LegHandles(end+1) = hLine;
LegText{end+1} = 'Exp. Strength';

set(gca,'FontSize',13);

% title('CDF - Tensile Modulus - Wood ','fontweight','bold','Fontsize',15,'FontName','cmr12');

% --- Plot data originally in dataset "Y data"


grid on;

% Create grid where function will be computed
XLim = get(gca,'XLim');
XLim = XLim + [0 100] * 0.01 * diff(XLim);
XGrid = linspace(.5*XLim(1),1.05*XLim(2),100);


% --- Create fit "fit 1" - Strength

% Fit this distribution to get parameter values
pd1 = fitdist(X, distb1);
YPlot = cdf(pd1,XGrid);
hLine = plot(XGrid,YPlot,'Color','k',...
    'LineStyle','-', 'LineWidth',2,...
    'Marker','none', 'MarkerSize',6);
LegHandles(end+1) = hLine;
LegText{end+1} = 'fit - Strength';


% Adjust figure
box on;
hold off;

% Create legend from accumulated handles and labels
hLegend = legend(LegHandles,LegText,'Orientation', 'vertical', 'FontSize', 9, 'Location', 'southeast');
set(hLegend,'Interpreter','none');

set(gca,'FontSize',13,'FontName','Trebuchet');
print('CDFVSA','-dmeta')
end




function clfall
FigList = findall(groot, 'Type', 'figure');
for iFig = 1:numel(FigList)
    try
        clf(FigList(iFig));
    catch
        % Nothing to do
    end
end
end